#include <stdlib.h>
#include "fila.h"
#include "item.h"

/* Apaga todos os itens da fila de forma iterativa e, ao final, libera a própria estrutura FILA. */

void fila_apagar(FILA **fila) {
    if (fila == NULL || *fila == NULL)
        return;

    /* Remove e apaga cada item até a fila ficar vazia */
    while (!fila_vazia(*fila)) {
        ITEM *it = fila_remover(*fila);
        item_apagar(&it);
    }

    /* Libera o objeto FILA e anula o ponteiro */
    free(*fila);
    *fila = NULL;
}